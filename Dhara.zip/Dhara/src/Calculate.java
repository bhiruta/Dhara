import com.sun.javafx.webkit.InputMethodClientImpl;

import java.util.Scanner;

public class Calculate {
    public static void main (String [] args) {
      Scanner scn = new Scanner(System.in);

        int num1;
        int num2;
        System.out.println("Enter the two value : " );
        char ch = scn.next().charAt(0);


        if (ch == '+') {

        }else if (ch == '-') {

        }else if (ch == '*') {


        }else if (ch == '/') {

        }else
            System.out.println("Enter tne value of symbol :");














    }
}


