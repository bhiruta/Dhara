public class Age {
    public static void main (String [] args) {
        int user = 17;

        if (user <= 18) {
            System.out.println("user is 18 to vote");
        }

          else {
              System.out.println("user is 17 to vote");
        }
    }

}
