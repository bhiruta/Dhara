public class Student {
    public static void main (String [] args){
        int m1 = 35;
        int m2 = 30;
        int m3 = 45;
        if (m1>35 && m2>30 && m3>45) {
            System.out.println("the student will be pass all subject");
        }
        else{
            System.out.println("the student will be fail");
        }
        }
    }


