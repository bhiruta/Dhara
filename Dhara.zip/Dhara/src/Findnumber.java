import java.util.Scanner;

    public class Findnumber {
        public static Scanner sc;

        public static void main(String[] args) {
            int number, i;
            float average;

            sc = new Scanner(System.in);

            System.out.println("Please enter how many numbers :");
            number = sc.nextInt();
            System.out.println("please enter the average :");

                number = sc.nextInt();
                average = number;


            }
        }
