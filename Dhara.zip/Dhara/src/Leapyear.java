public class Leapyear {
    public static void main (String [] args) {
        int year = 2004;
        // check if a leap year or not
        if(year % 4 == 0) ;
        System.out.println("Is a leap year");
        System.out.println("Not a leap year");
    }
}