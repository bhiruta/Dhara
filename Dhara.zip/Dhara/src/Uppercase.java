public class Uppercase {
    public static void main(String [] args) {
        //defining a alphabet
        int main ;

        char ch = 0;
        System.out.println("please enter any alphabet");
        if (ch >='a'&& ch <='z') {

            System.out.println("enter character is a lower class");
        }
         else
             System.out.println(" enter character is an upper class");

        }




            }









