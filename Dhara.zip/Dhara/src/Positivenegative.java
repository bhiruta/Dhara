public class Positivenegative {
    public static void main(String[] args) {
        int number = 0;
        int positive_Count = 0, Negative_Count = 0;
        System.out.println("/n please enter the number of an array :");

        if (number % 2 == 0) {
            System.out.println("positive number");
        } else {
            System.out.println("negative number");


        }


    }
}









