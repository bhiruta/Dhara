public class OddEvan {
    public static void main (String [] args){
  //defining a variable
        int a  = 23;
        int b  = 20;
        System.out.println( (a>b) ? a:b);


    }
}
